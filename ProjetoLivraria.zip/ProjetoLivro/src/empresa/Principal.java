package empresa;

public class Principal {

	public static void main(String[] args) {

		LivroDigital ld = new LivroDigital("Senhor dos Anéis",
				new Autor("Tolkein","Britânico", "tolkien@email.com"),
				"Aventura",5, 1000, 3500  );
		
		ld.info();
	}

}
