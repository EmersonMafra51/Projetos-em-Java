package empresa;

import java.util.Scanner;

public class Menu {
	
	private Scanner sc;
	private Cofrinho cofrinho;

	
	
//-------CONSTRUTOR MENU-----------//
public Menu() {
	
	sc = new Scanner(System.in);
	cofrinho = new Cofrinho();
	
}
//-------FIM DO CONSTRUTOR MENU---//


	//------INÍCIO MENU---------//

	public void MenuPrincipal() {
		System.out.println("|---------------COFRINHO-----------------|");
		System.out.println("1-ADICIONAR MOEDA: ");
		System.out.println("2-REMOVER MOEDA: ");
		System.out.println("3-LISTAR MOEDAS: ");
		System.out.println("4-CALCULAR TOTAL CONVERTIDO PARA REAL:");
		System.out.println("0- ENCERRAR SESSÃO:");
		System.out.println("|----------------------------------------|");
		
		//--------FIM DO MENU--------------------////
		
		
		
		//--------ENTRADA E VALIDAÇÃO DE DADOS------///
		 String selecao = sc.next();
		 
		 
		 //------------------ENCERRAR A SESSÃO---------------//
		 switch(selecao) {
		 case "0":
			 System.out.println("Sessão Encerrada!");
			 break;
		//------------------ FIM DE ENCERRAMENTO DE SESSÃO--------//
			 
			 
			 
			 
	    
			 //--------------- ADICIONAR MOEDAS ------------------//
		    case"1":
		    	exibirSubMenuAdicionarMoedas();
			    	  MenuPrincipal();
		    	
	    		    break;
		    //--------------------FIM DO ADICIONAR MOEDAS-----------------//
		    case"2":
		    	exibirSubMenuRemoverMoedas();
			    	  MenuPrincipal();
		    	
	    		    break;  
	    		    
	    		    
	    		    
	    		    
	        // -------------------REMOVER MOEDAS-------------------------//
	    		    
	    		    
	    		    
		    	  
		   //--------------------LISTAGEM DE MOEDAS ----------------------// 	  
		    case "3":
		    	cofrinho.listagemMoedas();
		    	MenuPrincipal();
		    	break;
		   //------------------ FIM DA LISTAGEM MOEDAS-----------------//
		    	
		    	
		    	
		    	
		   //-----------------CONVERSÃO DOS VALORES -------------------//
		    	
		    case"4":
		    	double valorTotalConvertido = cofrinho.totalConvertido();
		    	String valorTotalConvertidoTextual = String.format("%.2f", valorTotalConvertido); // ARREDONDANDO OS VALORES E FORMTATANDO
		    	valorTotalConvertidoTextual = valorTotalConvertidoTextual.replace(".",",");
		    	System.out.println("O valor total convertido para Real é: " + valorTotalConvertidoTextual);
		    	MenuPrincipal();
		    	
		    	break;
		    	//----------------FIM DA CONVERSÃO DE VALORES------------//
		    	
		    	
		    	
		    	
		    	  
			 
			 default:
				 System.out.println("Opção Inválida!");
				 	MenuPrincipal();
				 break;
		///////----------FIM DA ENTRADA E VALIDAÇÃO--------///////	
				 
	
				 
		 
		 }
		 
		 
	}
	
	//-----CRIAÇÃO DE UM MÉTODO PARA ADICIONAR MOEDAS------//

	private void exibirSubMenuAdicionarMoedas() {
		System.out.println("Escolha uma moeda: ");
    	System.out.println("1- REAL ");
    	System.out.println("2- DOLAR  ");
    	System.out.println("3- EURO ");
    	
    	int opcaoMoeda = sc.nextInt();
    	System.out.println("Voce escolheu a moeda: " +opcaoMoeda);
    	
    	System.out.println("Digite um valor: ");
    	String valorTextualMoeda = sc.next();
    	valorTextualMoeda = valorTextualMoeda.replace(",", ".");//CONVERTE A VÍRGULA EM PONTO//
    	double valorMoeda = Double.valueOf(valorTextualMoeda);
    
    	System.out.println("O valor da moeda é:  " +valorMoeda);
    	
    	Moeda moeda = null;
    	
    	if (opcaoMoeda == 1) {
    		 moeda = new Real (valorMoeda);
    	} else if(opcaoMoeda ==2) {
    	     moeda = new Dolar (valorMoeda);
    	}else if(opcaoMoeda ==3) {
    		  moeda = new Euro (valorMoeda);
    	}else {
    		System.out.println("Não existe esta moeda! ");

    	}
    	cofrinho.adicionar(moeda);
	     System.out.println("Moeda Adicionada com Sucesso!");
	   //-----FIM DO  MÉTODO PARA LISTAR MOEDAS------//
		
	}
	
	
	
	
	
	//-----CRIAÇÃO DE UM MÉTODO PARA REMOVER MOEDAS------//

		private void exibirSubMenuRemoverMoedas() {
			System.out.println("Escolha uma moeda: ");
	    	System.out.println("1- REAL ");
	    	System.out.println("2- DOLAR  ");
	    	System.out.println("3- EURO ");
	    	
	    	int opcaoMoeda = sc.nextInt();
	    	System.out.println("Voce escolheu a moeda: " +opcaoMoeda);
	    	
	    	System.out.println("Digite um valor: ");
	    	String valorTextualMoeda = sc.next();
	    	valorTextualMoeda = valorTextualMoeda.replace(",", ".");//CONVERTE A VÍRGULA EM PONTO//
	    	double valorMoeda = Double.valueOf(valorTextualMoeda);
	    
	    	System.out.println("O valor da moeda é:  " +valorMoeda);
	    	
	    	Moeda moeda = null;
	    	
	    	if (opcaoMoeda == 1) {
	    		 moeda = new Real (valorMoeda);
	    	} else if(opcaoMoeda ==2) {
	    	     moeda = new Dolar (valorMoeda);
	    	}else if(opcaoMoeda ==3) {
	    		  moeda = new Euro (valorMoeda);
	    	}else {
	    		System.out.println("Não existe esta moeda! ");

	    	}
	    	 if (cofrinho.remover(moeda)) {
	    		 System.out.println("Moeda Removida com Sucesso!");
	    	 }else {
	    		 System.out.println("Não foi encontrada nenhuma moeda com esse valor!");
	    	 }
		}
	
		   //-----FIM DO  MÉTODO PARA LISTAR MOEDAS------//
			
	
		
	}
	
	
	
	



