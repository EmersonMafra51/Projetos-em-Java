package empresa;

public abstract class Moeda {
	
	
//-------CRIANDO OS MÉTODOS DA CLASSE MOEDA-----//
	 double valor;
	
	public abstract void info();
	public abstract double converter();
	

}
