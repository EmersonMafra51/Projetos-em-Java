package empresa;

import java.util.ArrayList;

public class Cofrinho { 
	
	//--------CRIANDO A LISTAGEM DO COFRINHO-----//
	private ArrayList <Moeda> MoedasLista; //---SEGUINDO AS ORIENTAÇÕES DO UML DO TRABALHO QUE PEDE QUE SEJA UM ATRIBUTO PRIVADO--//
	
	public Cofrinho() { //----JÁ AQUI OS MÉTODOS SÃO PÚBLICOS POIS SERÃO ACESSADOS POR OUTRAS CLASSES---//
		this.MoedasLista = new ArrayList<>();
		
	}
	
	
	
	
	//------MÉTODO DE ADICIONAR MOEDAS-------//
	public void adicionar(Moeda moeda) {
		this.MoedasLista.add(moeda);
		
	}
	
	//----------FIM DO MÉTODO ADICIONAR MOEDAS-----//
	
	
	
	
	
	
	
	//----------MÉTODO DE REMOVER MOEDAS ------//
	
	public boolean  remover(Moeda moeda) {
		 return this.MoedasLista.remove(moeda);
		
	}
	//----------------FIM DO MÉTODO REMOVER MOEDAS------//
	
	
	
	
	
	
	
	//------MÉTODO DE LISTAR AS MOEDAS-----//
	
	public void listagemMoedas () {
		
		if (this.MoedasLista.isEmpty()) {
			System.out.println("Não existe nenhuma moeda no Cofrinho");
			return;
			
		}
		
			
		for(Moeda moeda: this.MoedasLista) {
			moeda.info();
		}
				
	  }

	public double totalConvertido(){
		
		if(this.MoedasLista.isEmpty()) {		
		   return 0;
		}
		
		double valorAcumulado = 0;
		
		for(Moeda moeda: this.MoedasLista) {
			valorAcumulado = valorAcumulado + moeda.converter();
		      }
		
		return valorAcumulado;
		
	}
	//----------------------FIM DA LISTAGEM MOEDAS-------------//	
	}


